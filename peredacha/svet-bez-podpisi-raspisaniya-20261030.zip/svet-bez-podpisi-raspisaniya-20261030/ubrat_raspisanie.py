# Убрать у покупателей подпись «цена по расписанию до Пн 08:00» и другие упоминания расписания скидки и времени ее
# окончания (задание владельца от 30.10.2026). Скидка, ее правила, интервалы, цены, зачеркнутая цена, значок −15 %,
# данные расписания в API (SR_SHOP.priceSchedule, ответы корзины), админка и примечание к заказу для менеджера не меняются.
#
# resources/app.js (одна строка около 1 МБ, поэтому вместо заплатки точные замены), 5 замен:
#  1. unitNote (карточка товара на компьютере и телефоне и все плитки через card(): каталог, бренды, поиск, подборки,
#     похожие, избранное, сравнение, просмотренные): без хвоста «цена по расписанию до …». Подпись «… ₽ за метр» у лент
#     остается; пустая подпись не выводится (sc-if hasNote), места не остается.
#  2. Корзина, строка товара: у товара со скидкой по расписанию нет подписи (была «цена по расписанию до …»); цена и
#     зачеркнутая прежняя цена как раньше.
#  3. Корзина, итог: строка «Скидка» с суммой (была «Скидка по расписанию −15% от РРЦ (до Пн 08:00)»).
#  4. Корзина, уведомление, когда цена сменилась при открытой странице: без слов о расписании и интервала.
#  5. Корзина, промокод: «На товары со скидкой промокод не действует.» (без «по расписанию»).
# resources/build.json: новая метка сборки (первые 10 знаков SHA-256 нового app.js), чтобы браузеры и сборка app.js с
#     контактами (storage/cache/app-*.js) обновились сами.
# src/Shop.php, 1 замена: ответ 409 «Цены изменились, пока корзина была открыта» без «(началась или закончилась скидка по
#     расписанию)». Корзина показывает этот текст покупателю. Проверка цен и сам ответ (priceChanged, changed, schedule) те же.
# src/MailTpl.php, 1 замена: в письме покупателю о заказе строка «Скидка: −N ₽ от обычных цен (уже в ценах)» вместо
#     примечания с названием и временем расписания; письмо менеджеру и карточка заказа в админке без изменений.
#
# Скрипт проверяет, что каждый фрагмент есть ровно один раз, проверяет PHP-файлы (php -l) и записывает все файлы сразу
# или ни одного.
#   python3 ubrat_raspisanie.py <корень сайта>                    показать, что будет сделано (ничего не пишет)
#   python3 ubrat_raspisanie.py <корень сайта> --zapis            записать
#   python3 ubrat_raspisanie.py <корень сайта> --obratno --zapis  снять правку обратными заменами
#   python3 ubrat_raspisanie.py <корень сайта> --otkat <папка>    вернуть файлы из резервной копии (app.js, build.json,
#                                                                Shop.php, MailTpl.php в одной папке)
#   --tolko-app   только app.js и build.json (подпись под ценой и тексты корзины); Shop.php и MailTpl.php не трогаются.
#                 С --otkat возвращает из копии только app.js и build.json.
import hashlib, json, os, shutil, subprocess, sys, tempfile

ROOT = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith('--') else ''
WRITE = '--zapis' in sys.argv
BACK = '--obratno' in sys.argv
ONLY_APP = '--tolko-app' in sys.argv
APP, BUILD = os.path.join(ROOT, 'resources', 'app.js'), os.path.join(ROOT, 'resources', 'build.json')
SHOP, MAIL = os.path.join(ROOT, 'src', 'Shop.php'), os.path.join(ROOT, 'src', 'MailTpl.php')
# app.js рабочего сайта на 30.10.2026 (совпадает с присланным current-label-base-20261030 и с отдаваемым /app.js?v=d823bd04e57a
# после подстановки контактов) и он же после правки
APP_DO = '3aeb36147e0eaba8118c779c43985f37fb46be7ebb3e0be40e6d7e579e08a0d5'
APP_POSLE = 'f9d3ca24da5b681b97d56eb0fc25f93718780670222faf9740c9740790e3c284'

ZAMENY = {
    APP: [
        ('карточка товара и плитки: подпись под ценой без «цена по расписанию до …» (unitNote)',
         '+(e.sched&&H?(e.perM?" · ":"")+"цена по расписанию до "+schedEnd():"");const dt=5*60*1e3;',
         ';const dt=5*60*1e3;'),
        ('корзина, строка товара: без подписи о расписании',
         'const B=A==="sched"?["sched",j?"цена по расписанию до "+j.endT:"цена по расписанию"]:A==="personal"?',
         'const B=A==="sched"?null:A==="personal"?'),
        ('корзина, итог: строка «Скидка» без расписания, процента от РРЦ и времени окончания',
         '"schedT":j?"Скидка по расписанию −"+String(j.pct).replace(".",",")+"% от РРЦ (до "+j.endT+")":"Скидка по расписанию",',
         '"schedT":"Скидка",'),
        ('корзина, уведомление о смене цены: без слов о расписании и интервала',
         '"priceNote":f?"Началась скидка по расписанию ("+f.label.replace(/:.*$/,"")+"): цены в корзине пересчитаны. Проверьте сумму перед оформлением.":"Скидка по расписанию закончилась: в корзине снова обычные цены. Проверьте сумму перед оформлением."',
         '"priceNote":f?"Цены в корзине пересчитаны со скидкой. Проверьте сумму перед оформлением.":"Скидка закончилась: в корзине снова обычные цены. Проверьте сумму перед оформлением."'),
        ('корзина, промокод: без «по расписанию»',
         '"На товары со скидкой по расписанию промокод не действует."',
         '"На товары со скидкой промокод не действует."'),
    ],
    SHOP: [
        ('ответ 409 о смене цен: без «(началась или закончилась скидка по расписанию)»',
         "'error' => 'Цены изменились, пока корзина была открыта' . (PriceSchedule::enabled() ? ' (началась или закончилась скидка по расписанию)' : '') . ': '",
         "'error' => 'Цены изменились, пока корзина была открыта: '"),
    ],
    MAIL: [
        ('письмо покупателю о заказе: сумма скидки без расписания и времени окончания',
         "        if (($o['price_note'] ?? '') !== '') $tot[] = ['Цены', (string) $o['price_note'] . ' (уже в ценах)'];\n",
         "        // покупателю только сумма скидки по расписанию (без условий и времени окончания), менеджеру примечание целиком\n"
         "        if (($o['price_note'] ?? '') !== '') {\n"
         "            if (!$client) $tot[] = ['Цены', (string) $o['price_note'] . ' (уже в ценах)'];\n"
         "            elseif (preg_match('/(−[^:]+)$/u', (string) $o['price_note'], $pm)) $tot[] = ['Скидка', trim($pm[1]) . ' (уже в ценах)'];\n"
         "        }\n"),
    ],
}

def sha(b): return hashlib.sha256(b).hexdigest()

def label(b_text, app_bytes):
    old = json.loads(b_text)['hash']; new = sha(app_bytes)[:10]
    if b_text.count('"hash": "%s"' % old) != 1: sys.exit('В build.json не найдена метка сборки. Ничего не изменено.')
    return b_text.replace('"hash": "%s"' % old, '"hash": "%s"' % new), old, new

def php_ok(text):
    try: r = subprocess.run(['php', '-l'], input=text.encode('utf-8'), capture_output=True, timeout=60)
    except FileNotFoundError: return None
    return r.returncode == 0

def otkat(src):
    pairs = [('app.js', APP), ('build.json', BUILD)] + ([] if ONLY_APP else [('Shop.php', SHOP), ('MailTpl.php', MAIL)])
    for name, _ in pairs:
        if not os.path.isfile(os.path.join(src, name)): sys.exit('Нет ' + os.path.join(src, name) + '. Ничего не изменено.')
    for name, p in pairs:
        tmp = p + '.tmp-otkat'; shutil.copyfile(os.path.join(src, name), tmp); os.replace(tmp, p)
        print('Возвращен %s %s' % (p, sha(open(p, 'rb').read())[:16]))

if __name__ == '__main__':
    if ONLY_APP:
        for p in (SHOP, MAIL): ZAMENY.pop(p)
    for p in [APP, BUILD] + list(ZAMENY):
        if not os.path.isfile(p): sys.exit('Нет ' + p + ': укажите корень сайта (папка с src/ и resources/)')
    if '--otkat' in sys.argv:
        i = sys.argv.index('--otkat')
        if i + 1 >= len(sys.argv): sys.exit('После --otkat укажите папку с резервной копией')
        otkat(sys.argv[i + 1]); sys.exit(0)
    if ONLY_APP: print('Только app.js и build.json: Shop.php и MailTpl.php не трогаются.')
    out = {}
    for p, zz in ZAMENY.items():
        raw = open(p, 'rb').read(); s = raw.decode('utf-8')
        done = all(s.count(new) == 1 and s.count(old) == 0 for _, old, new in zz)
        if not BACK and done: print('%s: правка уже есть (%s).' % (p, sha(raw)[:16])); continue
        if BACK and all(s.count(old) == 1 and s.count(new) == 0 for _, old, new in zz): print('%s: правки нет, снимать нечего.' % p); continue
        for name, old, new in (reversed(zz) if BACK else zz):
            a, b = (new, old) if BACK else (old, new)
            k = s.count(a)
            if k != 1: sys.exit('%s, «%s»: фрагмент найден %d раз(а), нужен 1. Ничего не изменено. Пришлите этот файл (без секретов), пакет пересоберу.' % (p, name, k))
            s = s.replace(a, b)
        out[p] = (raw, s.encode('utf-8'))
    if APP in out:
        b_text = open(BUILD, 'rb').read().decode('utf-8')
        b2, h0, h1 = label(b_text, out[APP][1])
        out[BUILD] = (b_text.encode('utf-8'), b2.encode('utf-8'))
        print('build.json: метка сборки %s -> %s' % (h0, h1))
    if not out: print('Изменений нет.'); sys.exit(0)
    for p in (SHOP, MAIL):
        if p in out:
            ok = php_ok(out[p][1].decode('utf-8'))
            if ok is False: sys.exit('%s после замены не проходит php -l. Ничего не изменено.' % p)
            if ok is None: print('php не найден, проверьте php -l %s после записи' % p)
    for p, (a, b) in out.items():
        print('%s: %s -> %s' % (p, sha(a)[:16], sha(b)[:16]))
    if APP in out and not BACK:
        a0, a1 = sha(out[APP][0]), sha(out[APP][1])
        if a0 == APP_DO and a1 != APP_POSLE: sys.exit('app.js после замен не совпал с ожидаемой суммой. Ничего не изменено.')
        print('app.js: ' + ('основа совпадает с ожидаемой (рабочий сайт 30.10.2026)' if a0 == APP_DO else 'основа другая, все фрагменты найдены; сумма после: ' + a1))
    if not WRITE: print('Проверка без записи. Для записи добавьте --zapis'); sys.exit(0)
    tmps = []
    try:
        for p, (_, b) in out.items():
            fd, tmp = tempfile.mkstemp(prefix='.tmp-raspisanie-', dir=os.path.dirname(p) or '.'); os.close(fd)
            open(tmp, 'wb').write(b); shutil.copymode(p, tmp); tmps.append((tmp, p))
        for tmp, p in tmps: os.replace(tmp, p)
    finally:
        for tmp, _ in tmps:
            if os.path.exists(tmp): os.remove(tmp)
    print('Записано. Очистка кэша не нужна: app.js для браузеров обновится по новой метке сборки. Если у PHP opcache без проверки '
          'времени файлов (opcache.validate_timestamps=0), перезапустить PHP-FPM.')
