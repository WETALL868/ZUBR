// Снимок блока цены карточки товара (как на снимке владельца) и текст блока: node zond-blok-ceny.js <адрес> <ширина> <путь> <файл>
const { chromium } = require('playwright');
const [BASE, W, PATH, OUT] = process.argv.slice(2);
(async () => {
  const b = await chromium.launch({ executablePath: '<chromium>', args: ['--ignore-certificate-errors', '--host-resolver-rules=MAP * zaglushka, EXCLUDE 127.0.0.1'] });
  const mob = +W < 700;
  const ctx = await b.newContext({ viewport: { width: +W, height: mob ? 844 : 900 }, deviceScaleFactor: 2, isMobile: mob, hasTouch: mob, ignoreHTTPSErrors: true, locale: 'ru-RU', timezoneId: 'Europe/Moscow' });
  await ctx.addInitScript(() => { try { localStorage.setItem('sr-theme', 'light'); } catch (e) {} });
  const p = await ctx.newPage();
  await p.goto(BASE + PATH, { waitUntil: 'load' });
  await p.waitForFunction(() => !document.getElementById('static') && !document.getElementById('first') && document.querySelector('#app main, #app .sr-mmain'), null, { timeout: 60000 });
  await p.waitForTimeout(2500);
  await p.evaluate(() => { const c = document.getElementById('sr-cookie'); if (c) c.style.display = 'none'; const btn = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Позже' && x.offsetParent); if (btn) btn.click(); });
  const box = await p.evaluateHandle(() => { const s = [...document.querySelectorAll('#app span')].find((x) => /^Цена за /.test(x.textContent.trim()) && x.offsetParent); return s ? s.parentElement : null; });
  const el = box.asElement();
  if (!el) { console.log(JSON.stringify({ err: 'нет блока цены' })); await b.close(); return; }
  await el.scrollIntoViewIfNeeded();
  await p.waitForTimeout(300);
  const text = await el.evaluate((e) => e.innerText.replace(/\n+/g, ' | '));
  const h = await el.evaluate((e) => Math.round(e.getBoundingClientRect().height));
  await el.screenshot({ path: OUT });
  console.log(JSON.stringify({ W, PATH, h, text }));
  await b.close();
})();
