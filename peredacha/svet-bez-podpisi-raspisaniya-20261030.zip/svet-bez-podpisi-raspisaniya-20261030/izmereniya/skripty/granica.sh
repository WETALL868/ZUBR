#!/bin/sh
# Граница интервала в открытом браузере, до и после правки: интервал кончается через 3 мин (konec) и начинается через
# 3 мин (nachalo). Время сервера не меняется, меняется только расписание в базе стенда.
S=<рабочая-папка>; R=$S/isp/rasp; V=$S/stend-psi
export NODE_PATH=<node_modules>
for rezhim in konec nachalo; do
  for v in do posle; do
    sh $R/vkl-rs.sh $v
    (cd $V && php $R/lab/rasp-nastroika.php $rezhim 3)
    for u in /cart /product/bra-arte-lamp-electra-a8233ap-1wh /catalog/lyustry; do curl -sk -o /dev/null -m 300 "https://stend-a$u"; done
    (cd $R/pw && node zond-granica.js https://stend-a 1440 $rezhim-$v 200 $R/snimki) > $R/izm/granica-$rezhim-$v.json 2>&1
  done
done
(cd $V && php $R/lab/rasp-nastroika.php kak-na-sajte)
echo готово
