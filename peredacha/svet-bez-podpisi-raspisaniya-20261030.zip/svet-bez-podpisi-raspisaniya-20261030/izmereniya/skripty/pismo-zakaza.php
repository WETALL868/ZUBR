<?php
// Письмо о заказе со скидкой по расписанию: MailTpl::order для покупателя и для менеджера из тестового заказа в памяти
// (в базу не пишется, письма не отправляются). Примечание price_note собрано так же, как в Shop.php при оформлении.
// Запуск из корня стенда: php pismo-zakaza.php
define('SR_CLI', 1);
require 'src/bootstrap.php';
$p = q('SELECT id, article, name, price FROM products WHERE article = ?', ['A8233AP-1WH'])->fetch();
[$price] = PriceSchedule::shown((float) $p['price'], null, (int) $p['id']);
$sched = (float) $p['price'] - $price;
$o = ['id' => 0, 'number' => 'T-000000', 'token' => 'test', 'created_at' => date('Y-m-d H:i:s'), 'name' => 'Проверка стенда', 'phone' => '+7 900 000-00-00', 'email' => 'test@example.invalid',
    'company' => '', 'inn' => '', 'kpp' => '', 'comment' => '', 'items_total' => $price, 'discount_sum' => 0, 'discount_pct' => 0, 'promo_sum' => 0, 'promo_code' => '', 'bonus_sum' => 0,
    'price_note' => mb_substr(PriceSchedule::label() . ': −' . money($sched) . ' от обычных цен', 0, 255),
    'delivery_type' => 'pickup', 'delivery_price' => 0, 'total' => $price, 'pay_method' => 'later', 'pay_status' => '', 'pay_url' => '', 'cdek_error' => '', 'info' => null,
    'city' => 'Москва', 'city_code' => 0, 'point_code' => '', 'point_address' => '', 'address' => '', 'tariff_code' => null];
$items = [['product_id' => (int) $p['id'], 'article' => $p['article'], 'name' => $p['name'], 'qty' => 1, 'price' => $price]];
foreach (['покупателю' => true, 'менеджеру' => false] as $who => $client) {
    try { $m = MailTpl::order($o, $items, $client); } catch (Throwable $e) { echo "$who: ошибка ", $e->getMessage(), "\n"; continue; }
    $lines = array_values(array_filter(explode("\n", (string) $m['text']), static fn($l) => preg_match('/Цены|Скидка|расписан|РРЦ|Итого|Товары/u', $l)));
    echo "== письмо $who (текстовая часть):\n  ", implode("\n  ", array_map('trim', $lines)), "\n";
    echo '  HTML: упоминаний «расписан»: ', preg_match_all('/расписан/u', (string) $m['html']), ', «до понедельника»: ', preg_match_all('/до понедельника/u', (string) $m['html']), "\n";
}
