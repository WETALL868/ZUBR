#!/bin/sh
# стенд A (stend-psi, 8099), подпись расписания: do - app.js рабочего сайта на 30.10 (восстановлен), Shop.php и MailTpl.php
# стенда; posle - те же файлы после ubrat_raspisanie.py. PHP остальной основы - после пакета svet-skorost-brendov-20261024.
S=<рабочая-папка>; V=$S/stend-psi; R=$S/isp/rasp
case "$1" in
 do) D=$R/osnova ;;
 posle) D=$R/posle ;;
 *) echo "do|posle"; exit 1 ;;
esac
for f in resources/app.js resources/build.json src/Shop.php src/MailTpl.php; do cp "$D/$f" "$V/$f.tmp-vkl" && mv "$V/$f.tmp-vkl" "$V/$f"; done
# встроенный сервер PHP проверяет время файлов раз в 2 с (opcache.revalidate_freq)
sleep 3
echo "$1 app.js $(sha256sum $V/resources/app.js | cut -c1-12) Shop.php $(sha256sum $V/src/Shop.php | cut -c1-12) MailTpl.php $(sha256sum $V/src/MailTpl.php | cut -c1-12)"
