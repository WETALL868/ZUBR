# Сводка zond-granica.js: python3 svod-granica.py <json>...
import sys,json
for f in sys.argv[1:]:
    t=open(f).read().strip()
    if not t: print(f.split('/')[-1], ': ещё идёт'); continue
    try: d=json.loads(t.splitlines()[-1])
    except Exception: print(f.split('/')[-1], ': ошибка', t[-300:]); continue
    print('==', d['TAG'])
    for k in ('before','after'):
        x=d[k]; print(' ', 'до границы' if k=='before' else 'после границы', x['at'][11:19], 'UTC')
        print('    карточка:', x['prod']['price'])
        print('    корзина, уведомление:', x['cart']['status'] or '-')
        print('    корзина, строки:', x['cart']['lines'])
        print('    корзина, итог:', x['cart']['sum'])
        print('    видимые упоминания расписания:', (x['cart']['hits']+x['prod']['hits'])[:4] or 'нет')
    print('  ошибки JS:', d['errs'] or 'нет')
