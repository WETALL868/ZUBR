// Избранное: цены плиток через N секунд после загрузки (проверка, не гонка ли). node zond-izbrannoe.js <адрес> <ширина>
const { chromium } = require('playwright');
const [BASE, W] = process.argv.slice(2);
(async () => {
  const b = await chromium.launch({ executablePath: '<chromium>', args: ['--ignore-certificate-errors', '--host-resolver-rules=MAP * zaglushka, EXCLUDE 127.0.0.1'] });
  const mob = +W < 700;
  const ctx = await b.newContext({ viewport: { width: +W, height: 844 }, isMobile: mob, hasTouch: mob, ignoreHTTPSErrors: true });
  await ctx.addInitScript(() => { try { localStorage.setItem('svetrussia.store.v1', JSON.stringify({ cart: {}, fav: { 'A8233AP-1WH': 1, 'A1527PL-5BK': 1, '371015205': 1 }, cmp: {}, seen: [] })); } catch (e) {} });
  const p = await ctx.newPage();
  await p.goto(BASE + '/favorites', { waitUntil: 'load' });
  const out = [];
  for (const t of [2500, 5000, 9000]) {
    await p.waitForTimeout(t - (out.length ? [2500, 5000, 9000][out.length - 1] : 0));
    out.push([t, await p.evaluate(() => [...document.querySelectorAll('#app [style*="color: var(--fg-1a6fc4)"][style*="font-weight: 800"]')].filter((e) => e.offsetParent).map((e) => e.textContent.trim()))]);
  }
  console.log(JSON.stringify(out));
  await b.close();
})();
