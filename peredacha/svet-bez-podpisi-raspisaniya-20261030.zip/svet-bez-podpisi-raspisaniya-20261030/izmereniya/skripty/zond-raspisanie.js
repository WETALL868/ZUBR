// Подпись расписания у покупателя: на каждой странице после запуска витрины видимые тексты с «расписан», «РРЦ» или временем
// окончания («до Пн 08:00» и т. п.), цены (основная, зачеркнутая, значки скидки), ошибки JS, снимок. Корзина, избранное,
// сравнение и просмотренные заполняются через localStorage. Сценарий: каталог -> карточка -> «Назад» -> F5 карточки.
// node zond-raspisanie.js <адрес> <ширина> <папка> <метка варианта>
const { chromium } = require('playwright');
const [BASE, W, OUT, TAG] = process.argv.slice(2);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SCHED = ['A8233AP-1WH', 'A1527PL-5BK'];   // со скидкой по расписанию (РРЦ есть)
const PLAIN = ['371015205'];                    // без РРЦ: скидки по расписанию нет
const ARTS = [...SCHED, ...PLAIN];
const store = { cart: { 'A8233AP-1WH': 1, 'A1527PL-5BK': 2, '371015205': 1 }, fav: Object.fromEntries(ARTS.map((a) => [a, 1])), cmp: Object.fromEntries(ARTS.map((a) => [a, 1])), seen: ARTS };
const PAGES = [
  ['kartochka-bra', '/product/bra-arte-lamp-electra-a8233ap-1wh'],
  ['kartochka-lyustra', '/product/potolochnaya-lyustra-arte-lamp-tracy-a1527pl-5bk'],
  ['kartochka-bez-rrc', '/product/lyustra-de-city-avrora-5-e14-chernyy-52-sm-371015205'],
  ['katalog-bra', '/catalog/bra-i-podsvetka'],
  ['katalog-lyustry', '/catalog/lyustry'],
  ['brend', '/brands/arte-lamp'],
  ['poisk', '/search?q=A8233AP'],
  ['podborka', '/catalog/lyustry/dlya-kuhni'],
  ['izbrannoe', '/favorites'],
  ['sravnenie', '/compare'],
  ['prosmotrennye', '/viewed'],
  ['korzina', '/cart'],
];
const collect = () => {
  const vis = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const root = document.getElementById('app') || document.body;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const hits = []; let n;
  const re = /расписан|РРЦ|\bдо (Пн|Вт|Ср|Чт|Пт|Сб|Вс|пн|вт|ср|чт|пт|сб|вс)\b|\bдо \d{1,2}:\d{2}\b/;
  while ((n = w.nextNode())) { const t = n.textContent.trim(); if (t && re.test(t) && n.parentElement && vis(n.parentElement)) hits.push(t.slice(0, 160)); }
  const txt = (sel) => [...root.querySelectorAll(sel)].filter(vis).map((e) => e.textContent.replace(/\s+/g, ' ').trim());
  return {
    hits: [...new Set(hits)],
    old: txt('s').slice(0, 40),
    badges: txt('.sr-disc-b').slice(0, 40),
    notes: txt('.sr-ci-unit em').slice(0, 20),
    sum: txt('#sr-sum .sr-cart-line').slice(0, 12),
    status: txt('.sr-status'),
    prices: txt('[style*="color: var(--fg-1a6fc4)"][style*="font-weight: 800"]').slice(0, 40),
    errs: (window.__errs || []).slice(0, 5),
    first: !!document.getElementById('first'), stat: !!document.getElementById('static'),
  };
};
(async () => {
  const b = await chromium.launch({ executablePath: '<chromium>', args: ['--ignore-certificate-errors', '--host-resolver-rules=MAP * zaglushka, EXCLUDE 127.0.0.1'] });
  const mob = +W < 700;
  const ctx = await b.newContext({ viewport: { width: +W, height: mob ? 844 : 900 }, deviceScaleFactor: mob ? 2 : 1, isMobile: mob, hasTouch: mob, ignoreHTTPSErrors: true, locale: 'ru-RU', timezoneId: 'Europe/Moscow' });
  await ctx.addInitScript((st) => {
    try { if (!sessionStorage.getItem('zond-init')) { localStorage.setItem('svetrussia.store.v1', JSON.stringify(st)); sessionStorage.setItem('zond-init', '1'); } localStorage.setItem('sr-theme', 'light'); } catch (e) {}
    window.__errs = []; addEventListener('error', (e) => window.__errs.push(String(e.message).slice(0, 160)));
  }, store);
  const p = await ctx.newPage();
  const pageErrs = [];
  p.on('pageerror', (e) => pageErrs.push(String(e).slice(0, 200)));
  const ready = async () => {
    await p.waitForFunction(() => !document.getElementById('static') && !document.getElementById('first') && document.querySelector('#app main, #app .sr-mmain, #app [data-feed], #app .sr-cart, #app section'), null, { timeout: 60000 }).catch(() => pageErrs.push('витрина не заменила первый экран за 60 с'));
    await sleep(2500);
    await p.evaluate(() => { const c = document.getElementById('sr-cookie'); if (c) c.style.display = 'none'; const btn = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Позже' && x.offsetParent); if (btn) btn.click(); });
    await sleep(300);
  };
  const res = [];
  for (const [name, path] of PAGES) {
    // HTML сервера до запуска скриптов: подпись не должна приходить и с сервера
    const html = await ctx.request.get(BASE + path, { timeout: 120000 }).then((x) => x.text()).catch((e) => "ОШИБКА " + e.message);
    const htmlHits = (html.match(/[^<>]{0,60}(расписан|до (Пн|Вт|Ср|Чт|Пт|Сб|Вс) \d)[^<>]{0,60}/g) || []).filter((x) => !/window\.|SR_SHOP|"label"/.test(x));
    await p.goto(BASE + path, { waitUntil: 'load' });
    await ready();
    const r = await p.evaluate(collect);
    // блок цены на карточке и итог корзины ближе к центру снимка
    await p.evaluate((nm) => { const e = nm === 'korzina' ? document.getElementById('sr-sum') : nm.startsWith('kartochka') ? [...document.querySelectorAll('#app section, #app div')].find((x) => /В корзину/.test(x.textContent) && x.getBoundingClientRect().height < 700 && x.getBoundingClientRect().height > 120) : null; if (e) e.scrollIntoView({ block: 'center' }); }, name);
    await sleep(400);
    await p.screenshot({ path: `${OUT}/${TAG}-${W}-${name}.png` });
    res.push({ name, path, htmlHits, ...r });
  }
  // сценарий: каталог -> карточка товара со скидкой -> «Назад» -> F5 карточки
  const scen = {};
  await p.goto(BASE + '/catalog/bra-i-podsvetka', { waitUntil: 'load' }); await ready();
  const link = await p.$('#app a[href*="/product/"][data-sec], #app a[href*="Product"]');
  if (link) { await link.click(); await sleep(500); await p.waitForURL(/\/product\//, { timeout: 30000 }).catch(() => {}); await sleep(2500); scen.kartochka = { url: p.url().replace(BASE, ''), ...(await p.evaluate(collect)) }; }
  await p.goBack(); await sleep(3000); scen.nazad = { url: p.url().replace(BASE, ''), ...(await p.evaluate(collect)) };
  await p.goto(BASE + '/product/bra-arte-lamp-electra-a8233ap-1wh', { waitUntil: 'load' }); await ready();
  await p.reload({ waitUntil: 'load' }); await ready(); scen.f5 = { url: p.url().replace(BASE, ''), ...(await p.evaluate(collect)) };
  console.log(JSON.stringify({ TAG, W, pages: res, scen, pageErrs }));
  await b.close();
})();
