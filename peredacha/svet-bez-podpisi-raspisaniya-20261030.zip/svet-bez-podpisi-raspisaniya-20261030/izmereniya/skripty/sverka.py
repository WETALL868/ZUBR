# Сверка цен «до» и «после» по зонду: одинаковые ли основные цены, зачеркнутые цены и значки на каждой странице;
# подписи о расписании должны остаться только «до». python3 sverka.py <do.json> <posle.json>
import sys,json
L=lambda f: json.loads(open(f).read().strip().splitlines()[-1])
a,b=L(sys.argv[1]),L(sys.argv[2])
ok=True
for x,y in zip(a['pages'],b['pages']):
    same=all(x[k]==y[k] for k in ('prices','old','badges'))
    ok&=same and not y['hits'] and not y['htmlHits']
    print('%-18s цены, зачеркнутые, значки: %s | подписи до: %d, после: %d | итог корзины после: %s' % (x['name'], 'совпадают' if same else 'РАЗНЫЕ', len(x['hits']), len(y['hits']), y['sum'][:3] if y['sum'] else '-'))
for k in a['scen']:
    same=all(a['scen'][k][f]==b['scen'][k][f] for f in ('prices','old','badges'))
    ok&=same and not b['scen'][k]['hits']
    print('сценарий %-9s цены совпадают: %s | подписи после: %d' % (k, same, len(b['scen'][k]['hits'])))
print('ошибки JS до/после:', a['pageErrs'], b['pageErrs'])
print('ИТОГ:', 'всё совпадает, подписей нет' if ok else 'ЕСТЬ РАСХОЖДЕНИЯ')
