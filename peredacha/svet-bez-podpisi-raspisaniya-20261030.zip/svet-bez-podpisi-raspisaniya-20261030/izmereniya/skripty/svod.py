# Сводка зонда zond-raspisanie.js: python3 svod.py <json>
import sys,json
d=json.loads(open(sys.argv[1]).read().strip().splitlines()[-1])
print(d['TAG'], d['W'])
for p in d['pages']:
    print(' ', p['name'], '| видно:', p['hits'][:3], '| HTML:', p['htmlHits'][:2], '| зачеркн.:', p['old'][:2], '| значки:', p['badges'][:2], '| строки корзины:', p['notes'], '| итог:', p['sum'][:4], '| JS:', p['errs'])
for k,v in d['scen'].items(): print('  сценарий', k, v['url'], '| видно:', v['hits'][:3], '| зачеркн.:', v['old'][:2], '| значки:', v['badges'][:2])
print('  ошибки страницы:', d['pageErrs'])
