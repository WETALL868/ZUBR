// Граница интервала скидки в открытом браузере: корзина и карточка товара открыты до границы, состояние снимается до и
// после нее (цена пересчитывается в браузере сама по интервалам с сервера). node zond-granica.js <адрес> <ширина> <метка> <ждать, с> <папка снимков>
const { chromium } = require('playwright');
const [BASE, W, TAG, WAIT, OUT] = process.argv.slice(2);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const state = () => {
  const vis = (e) => e && e.offsetParent !== null;
  const t = (sel) => [...document.querySelectorAll(sel)].filter(vis).map((e) => e.innerText.replace(/\s+/g, ' ').trim());
  const box = [...document.querySelectorAll('#app span')].find((x) => /^Цена за /.test(x.textContent.trim()) && vis(x));
  return { price: box ? box.parentElement.innerText.split('\n').slice(0, 6).join(' | ') : null, status: t('.sr-status'), lines: t('.sr-ci-unit'), sum: t('#sr-sum .sr-cart-line').slice(0, 4),
    hits: (document.body.innerText.match(/[^\n]*(расписан|РРЦ|до (пн|вт|ср|чт|пт|сб|вс|Пн|Вт|Ср|Чт|Пт|Сб|Вс) \d)[^\n]*/g) || []).slice(0, 6) };
};
(async () => {
  const b = await chromium.launch({ executablePath: '<chromium>', args: ['--ignore-certificate-errors', '--host-resolver-rules=MAP * zaglushka, EXCLUDE 127.0.0.1'] });
  const mob = +W < 700;
  const ctx = await b.newContext({ viewport: { width: +W, height: 900 }, isMobile: mob, hasTouch: mob, ignoreHTTPSErrors: true, locale: 'ru-RU', timezoneId: 'Europe/Moscow' });
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('zond-gr')) { localStorage.setItem('svetrussia.store.v1', JSON.stringify({ cart: { 'A8233AP-1WH': 1, 'A1527PL-5BK': 2 }, fav: {}, cmp: {}, seen: [] })); localStorage.setItem('zond-gr', '1'); } } catch (e) {} });
  const cart = await ctx.newPage(), prod = await ctx.newPage();
  const errs = [];
  for (const p of [cart, prod]) p.on('pageerror', (e) => errs.push(String(e).slice(0, 160)));
  await cart.goto(BASE + '/cart', { waitUntil: 'load' });
  await prod.goto(BASE + '/product/bra-arte-lamp-electra-a8233ap-1wh', { waitUntil: 'load' });
  await sleep(6000);
  const before = { cart: await cart.evaluate(state), prod: await prod.evaluate(state), at: new Date().toISOString() };
  await sleep(+WAIT * 1000);
  const after = { cart: await cart.evaluate(state), prod: await prod.evaluate(state), at: new Date().toISOString() };
  await cart.evaluate(() => { const e = document.querySelector('.sr-status') || document.getElementById('sr-sum'); if (e) e.scrollIntoView({ block: 'start' }); window.scrollBy(0, -20); });
  await sleep(300);
  await cart.screenshot({ path: `${OUT}/granica-${TAG}-${W}-korzina.png` });
  console.log(JSON.stringify({ TAG, W, before, after, errs }));
  await b.close();
})();
