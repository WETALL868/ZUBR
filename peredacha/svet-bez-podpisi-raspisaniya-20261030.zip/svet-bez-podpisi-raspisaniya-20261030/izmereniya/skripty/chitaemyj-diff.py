# Читаемый дифф одной строки app.js: строка режется по ";" и перед полями объектов (,"имя":), только для чтения.
# python3 chitaemyj-diff.py <app.js до> <app.js после> <файл диффа>
import sys,re,difflib
a=open(sys.argv[1],encoding='utf-8').read(); b=open(sys.argv[2],encoding='utf-8').read()
tok=lambda s: re.split(r'(?<=;)|(?<=,)(?="[A-Za-z]+":)', s)
ta,tb=tok(a),tok(b)
out=['# Читаемый дифф resources/app.js (одна строка около 1 МБ разрезана по ";" и полям объектов только для чтения).',
     '# Применять скриптом ubrat_raspisanie.py, не этим файлом.',
     '--- resources/app.js (рабочий сайт 30.10.2026, 3aeb36147e0e...)',
     '+++ resources/app.js (после правки, f9d3ca24da5b...)']
out+= [l for l in difflib.unified_diff(ta,tb,lineterm='',n=1) if not l.startswith(('---','+++'))]
open(sys.argv[3],'w',encoding='utf-8').write('\n'.join(out)+'\n')
print(len(out),'строк, самая длинная', max(map(len,out)))
