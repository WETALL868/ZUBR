#!/bin/sh
# Ответ 409 при смене цены: заказ с намеренно устаревшей ценой (5 930 ₽ вместо 5 041 ₽ по расписанию). Сервер отказывает до
# создания заказа; число заказов в базе стенда до и после выводится. Почта не отправляется (заказ не создается).
B=https://stend-a
n0=$(mysql -N svetrussia_var -e "select count(*) from orders")
curl -sk -m 60 -H 'Content-Type: application/json' -X POST "$B/api/order" --data '{"name":"Проверка стенда","phone":"+7 900 000-00-00","agree":1,"buyer":"person","payment":"later","delivery":{"type":"pickup"},"items":[{"art":"A8233AP-1WH","qty":1,"price":5930}]}' -w '\nHTTP %{http_code}\n'
n1=$(mysql -N svetrussia_var -e "select count(*) from orders")
echo "заказов в базе стенда: до $n0, после $n1"
