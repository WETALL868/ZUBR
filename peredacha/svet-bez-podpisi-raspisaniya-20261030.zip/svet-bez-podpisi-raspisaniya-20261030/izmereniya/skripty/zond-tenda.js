// Товар со снимка владельца: плитка Arte Lamp TENDA A1624PL-6WH в /catalog/lyustry и блок цены его карточки, снимки и текст.
// node zond-tenda.js <адрес> <ширина> <метка> <папка>
const { chromium } = require('playwright');
const [BASE, W, TAG, OUT] = process.argv.slice(2);
const ART = 'A1624PL-6WH';
(async () => {
  const b = await chromium.launch({ executablePath: '<chromium>', args: ['--ignore-certificate-errors', '--host-resolver-rules=MAP * zaglushka, EXCLUDE 127.0.0.1'] });
  const mob = +W < 700;
  const ctx = await b.newContext({ viewport: { width: +W, height: mob ? 844 : 900 }, deviceScaleFactor: 2, isMobile: mob, hasTouch: mob, ignoreHTTPSErrors: true, locale: 'ru-RU', timezoneId: 'Europe/Moscow' });
  await ctx.addInitScript(() => { try { localStorage.setItem('sr-theme', 'light'); } catch (e) {} });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 160)));
  const ready = async () => {
    await p.waitForFunction(() => !document.getElementById('static') && !document.getElementById('first') && document.querySelector('#app main, #app .sr-mmain, #app [data-feed]'), null, { timeout: 60000 });
    await p.waitForTimeout(2500);
    await p.evaluate(() => { const c = document.getElementById('sr-cookie'); if (c) c.style.display = 'none'; const btn = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Позже' && x.offsetParent); if (btn) btn.click(); });
  };
  const res = { TAG, W };
  await p.goto(BASE + '/catalog/lyustry', { waitUntil: 'load' });
  await ready();
  // плитка: самый маленький блок с артикулом и ценой
  const tile = await p.evaluateHandle((art) => {
    const c = [...document.querySelectorAll('#app a, #app div, #app article')].filter((e) => e.offsetParent && e.innerText.includes(art) && /₽/.test(e.innerText));
    c.sort((a, b) => a.innerText.length - b.innerText.length);
    let e = c[0]; while (e && e.parentElement && e.getBoundingClientRect().height < 250) e = e.parentElement;
    return e || null;
  }, ART);
  const t = tile.asElement();
  if (t) { await t.scrollIntoViewIfNeeded(); await p.waitForTimeout(500); res.tile = await t.evaluate((e) => e.innerText.replace(/\n+/g, ' | ')); await t.screenshot({ path: `${OUT}/tenda-${TAG}-${W}-plitka.png` }); } else res.tile = 'не найдена';
  await p.goto(BASE + '/product/potolochnaya-lyustra-arte-lamp-tenda-a1624pl-6wh', { waitUntil: 'load' });
  await ready();
  const box = (await p.evaluateHandle(() => { const s = [...document.querySelectorAll('#app span')].find((x) => /^Цена за /.test(x.textContent.trim()) && x.offsetParent); return s ? s.parentElement : null; })).asElement();
  if (box) { await box.scrollIntoViewIfNeeded(); await p.waitForTimeout(300); res.card = await box.evaluate((e) => e.innerText.replace(/\n+/g, ' | ')); res.cardH = await box.evaluate((e) => Math.round(e.getBoundingClientRect().height)); await box.screenshot({ path: `${OUT}/tenda-${TAG}-${W}-kartochka.png` }); }
  res.errs = errs;
  console.log(JSON.stringify(res));
  await b.close();
})();
