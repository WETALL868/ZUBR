<?php
// Стенд: скидка по расписанию в базе стенда (только ветка settings.shop.price_schedule, остальное не читается и не выводится).
// Время сервера не меняется: активный и неактивный интервал задаются самим расписанием.
//   php rasp-nastroika.php kak-na-sajte    выходные пт 18:00 - пн 08:00, 15 % (как на рабочем сайте)
//   php rasp-nastroika.php ne-sejchas      то же, но интервал вт 18:00 - ср 08:00 (сейчас не действует)
//   php rasp-nastroika.php konec <мин>     интервал кончается через <мин> минут (проверка смены цены в открытом браузере)
//   php rasp-nastroika.php nachalo <мин>   интервал начинается через <мин> минут
//   php rasp-nastroika.php vernut          вернуть ветку, сохраненную при первом вызове
// rrc_days = 400: на стенде РРЦ из прайсов старше 7 дней, иначе скидке не от чего считаться (на рабочем сайте 7, не меняется).
define('SR_CLI', 1);
require 'src/bootstrap.php';
$save = __DIR__ . '/price_schedule.ishodnaya.json';
$cur = setting('shop', []) ?: [];
if (!is_file($save)) file_put_contents($save, json_encode(['est' => array_key_exists('price_schedule', $cur), 'v' => $cur['price_schedule'] ?? null], JSON_UNESCAPED_UNICODE));
$mode = $argv[1] ?? '';
$tz = new DateTimeZone('Europe/Moscow');
$hm = static fn(int $t): string => (new DateTimeImmutable('@' . $t))->setTimezone($tz)->format('H:i');
$base = ['enabled' => true, 'pct' => '15', 'mode' => 'weekend', 'wk_from_day' => '5', 'wk_from' => '18:00', 'wk_to_day' => '1', 'wk_to' => '08:00', 'rrc_days' => '400'];
switch ($mode) {
    case 'kak-na-sajte': $ps = $base; break;
    case 'ne-sejchas': $ps = ['wk_from_day' => '2', 'wk_to_day' => '3'] + $base; break;
    case 'konec': $m = max(1, (int) ($argv[2] ?? 2)); $ps = ['mode' => 'night', 'days' => [1, 2, 3, 4, 5, 6, 7], 'from' => $hm(time() - 3600), 'to' => $hm(time() + 60 * $m)] + $base; break;
    case 'nachalo': $m = max(1, (int) ($argv[2] ?? 2)); $ps = ['mode' => 'night', 'days' => [1, 2, 3, 4, 5, 6, 7], 'from' => $hm(time() + 60 * $m), 'to' => $hm(time() + 60 * $m + 3 * 3600)] + $base; break;
    case 'vernut':
        $o = json_decode((string) file_get_contents($save), true);
        if ($o['est']) $cur['price_schedule'] = $o['v']; else unset($cur['price_schedule']);
        setting_set('shop', $cur); cache_clear(); echo "ветка price_schedule возвращена\n"; exit(0);
    default: fwrite(STDERR, "kak-na-sajte | ne-sejchas | konec <мин> | nachalo <мин> | vernut\n"); exit(1);
}
$cur['price_schedule'] = $ps;
setting_set('shop', $cur);
cache_clear();
// opt() кэширует настройки в процессе: проверка в новом процессе
echo $mode, ': ', trim((string) shell_exec('php -r ' . escapeshellarg('define("SR_CLI",1); require "src/bootstrap.php"; $c = PriceSchedule::client(); echo json_encode(["enabled" => PriceSchedule::enabled(), "label" => $c["label"] ?? null, "active" => PriceSchedule::activeAt() ? array_map(fn($t) => date("D H:i", $t), PriceSchedule::activeAt()) : null], JSON_UNESCAPED_UNICODE);'))), "\n";
